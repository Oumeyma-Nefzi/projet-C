#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"fonctionoum.h"



void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowajout,*tache;
windowajout=create_windowajout();
gtk_widget_show (windowajout);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}



void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *windowmodif,*tache;

windowmodif=create_windowmodif();
gtk_widget_show (windowmodif);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}



void
on_buttonsup_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowsup,*tache;
windowsup=create_windowsup();
gtk_widget_show (windowsup);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}


void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowrech,*tache;
windowrech=create_windowrech();
gtk_widget_show (windowrech);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}


void
on_buttonaff_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowaff,*windowtache,*treeview1;
windowtache=lookup_widget(button,"windowtache");
gtk_widget_destroy(windowtache);
windowaff=lookup_widget(button,"windowaff");
windowaff=create_windowaff();
gtk_widget_show (windowaff);
treeview1=lookup_widget(windowaff,"treeview1");
afficher_tout(treeview1);
}


void
on_buttonnb_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windownbetud,*tache;
windownbetud=create_windownbetud();
gtk_widget_show (windownbetud);
tache=lookup_widget(button,"windowtache");
gtk_widget_destroy(tache);
}


void
on_buttonrech1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *iden, *windowrech;
iden = lookup_widget(button,"entryrech");
strcpy(eh.identifiant, gtk_entry_get_text(GTK_ENTRY(iden)));
supprimer_etudiant(eh.identifiant);
}


void
on_buttonsup1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

GtkWidget *identifiant,*labelsuppetud;

char identifiant1[30];
identifiant = lookup_widget(button,"entrysup");
strcpy(identifiant1, gtk_entry_get_text(GTK_ENTRY(identifiant)));

if (strcmp(identifiant1,"")!=0)
{
supprimer_etudiant(identifiant1);
gtk_label_set_text(GTK_LABEL(labelsuppetud)," étudiant supprimé! ");
}
else 
	{
	gtk_label_set_text(GTK_LABEL(labelsuppetud)," étudiant introuvable ! ");
	}
}
void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
FILE *f ; 
int n;

GtkWidget *sexe,*nom,*prenom,*identifiant,*classe,*num_telephone,*nom_parent,*prenom_parent,*num_telephone_parent,*foyer,*niveau,*num_de_la_chambre, *windowajout, *windowaff, *labelverifajout, *treeview1; 

sexe=lookup_widget(togglebutton,"comboboxsexe");
strcpy(eh.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)));



nom= lookup_widget(togglebutton,"entrynomeh");
prenom = lookup_widget(togglebutton,"entryprenomeh");
identifiant = lookup_widget(togglebutton,"entryideneh");
classe = lookup_widget(togglebutton,"entryclasseeh");
num_telephone = lookup_widget(togglebutton,"entrynumeh");
nom_parent = lookup_widget(togglebutton,"entrynompareh");
prenom_parent = lookup_widget(togglebutton,"entryprenompareh");
num_telephone_parent = lookup_widget(togglebutton,"entrynumpareh");
foyer = lookup_widget(togglebutton,"entryfoyereh");
niveau = lookup_widget(togglebutton,"entryniveaueh");
num_de_la_chambre = lookup_widget(togglebutton,"entrynumchameh");


strcpy(eh.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(eh.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(eh.identifiant, gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(eh.classe, gtk_entry_get_text(GTK_ENTRY(classe)));
strcpy(eh.num_telephone, gtk_entry_get_text(GTK_ENTRY(num_telephone)));
strcpy(eh.nom_parent, gtk_entry_get_text(GTK_ENTRY(nom_parent)));
strcpy(eh.prenom_parent, gtk_entry_get_text(GTK_ENTRY(prenom_parent)));
strcpy(eh.num_telephone_parent, gtk_entry_get_text(GTK_ENTRY(num_telephone_parent)));
strcpy(eh.foyer, gtk_entry_get_text(GTK_ENTRY(foyer)));
strcpy(eh.niveau, gtk_entry_get_text(GTK_ENTRY(niveau)));
strcpy(eh.num_de_la_chambre, gtk_entry_get_text(GTK_ENTRY(num_de_la_chambre)));

ajouter_etudiant(eh);


switch (n) 
{
case 0 : 
windowaff=create_windowaff(); 
gtk_widget_show(windowaff);
gtk_widget_hide(windowajout);
treeview1=lookup_widget(windowaff,"treeview1");
afficher_tout(treeview1);  break ; 
case 1 : gtk_label_set_text(GTK_LABEL(labelverifajout)," Il faut remplir tout les champs ! "); break ; 
case 2 : gtk_label_set_text(GTK_LABEL(labelverifajout)," Ce nom d'étudiant est déjà ajouté ! ");break ; 

}
}


int c=0;
void
on_radiobuttonf_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
c=1;
}


void
on_radiobuttonm_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
c=2;
}


void
on_checkbuttonenregistrer_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
GtkWidget *sexe,*nom,*prenom,*identifiant,*classe,*num_telephone,*nom_parent,*prenom_parent,*num_telephone_parent,*foyer,*niveau,*num_de_la_chambre, *windowajout, *labelverifmodif;

nom= lookup_widget(togglebutton,"entrynomeh1");
prenom = lookup_widget(togglebutton,"entrypreeh1");
identifiant = lookup_widget(togglebutton,"entryideneh1");
classe = lookup_widget(togglebutton,"entryclasseeh1");
num_telephone = lookup_widget(togglebutton,"entrynumeh1");
nom_parent = lookup_widget(togglebutton,"entrynompareeh1");
prenom_parent = lookup_widget(togglebutton,"entryprepareh1");
num_telephone_parent = lookup_widget(togglebutton,"entrynumpareh1");
foyer = lookup_widget(togglebutton,"entryfoyereh1");
niveau = lookup_widget(togglebutton,"entryniveh1");
num_de_la_chambre = lookup_widget(togglebutton,"entrynumchameh1");


strcpy(eh.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(eh.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(eh.identifiant, gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(eh.classe, gtk_entry_get_text(GTK_ENTRY(classe)));
strcpy(eh.num_telephone, gtk_entry_get_text(GTK_ENTRY(num_telephone)));
strcpy(eh.nom_parent, gtk_entry_get_text(GTK_ENTRY(nom_parent)));
strcpy(eh.prenom_parent, gtk_entry_get_text(GTK_ENTRY(prenom_parent)));
strcpy(eh.num_telephone_parent, gtk_entry_get_text(GTK_ENTRY(num_telephone_parent)));
strcpy(eh.foyer, gtk_entry_get_text(GTK_ENTRY(foyer)));
strcpy(eh.niveau, gtk_entry_get_text(GTK_ENTRY(niveau)));
strcpy(eh.num_de_la_chambre, gtk_entry_get_text(GTK_ENTRY(num_de_la_chambre)));

if (c==1)
strcpy(eh.sexe,"feminin");
else if (c==2)
strcpy(eh.sexe,"masculin");

modifier_etudiant (eh);
 gtk_label_set_text(GTK_LABEL(labelverifmodif)," la modification a été effectuée avec succés ! ");
}


void
on_buttonquittajout_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windowajout;
windowajout=lookup_widget(button,"windowajout");
gtk_widget_destroy(windowajout);
tache=create_windowtache();
gtk_widget_show(tache);

}


void
on_buttonquittmodif_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windowmodif;
windowmodif=lookup_widget(button,"windowmodif");
gtk_widget_destroy(windowmodif);
tache=create_windowtache();
gtk_widget_show(tache);
}


void
on_buttonquittrech_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windowrech;
windowrech=lookup_widget(button,"windowrech");
gtk_widget_destroy(windowrech);
tache=create_windowtache();
gtk_widget_show(tache);
}


void
on_buttonquittsupp_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windowsup;
windowsup=lookup_widget(button,"windowsup");
gtk_widget_destroy(windowsup);
tache=create_windowtache();
gtk_widget_show(tache);
}


void
on_buttonquittnbet_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windownbetud;
windownbetud=lookup_widget(button,"windownbetud");
gtk_widget_destroy(windownbetud);
tache=create_windowtache();
gtk_widget_show(tache);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* identifiant;
gchar* classe;
gchar* sexe;
gchar* num_telephone;
gchar* nom_parent;
gchar* prenom_parent;
gchar* num_telephone_parent;
gchar* foyer;
gchar* niveau;
gchar* num_de_la_chambre;
etudiant_heberge eh;
GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,2,&identifiant,3,&classe,4,&sexe,5,&num_telephone,6,&nom_parent,7,&prenom_parent,8,&num_telephone_parent,9,&foyer,10,&niveau,11,&num_de_la_chambre,-1);
strcpy(eh.nom, nom);
strcpy(eh.prenom, prenom);
strcpy(eh.identifiant, identifiant);
strcpy(eh.classe, classe);
strcpy(eh.sexe, sexe);
strcpy(eh.num_telephone, num_telephone);
strcpy(eh.nom_parent, nom_parent);
strcpy(eh.prenom_parent, prenom_parent);
strcpy(eh.num_telephone_parent, num_telephone_parent);
strcpy(eh.foyer, foyer);
strcpy(eh.niveau, niveau);
strcpy(eh.num_de_la_chambre, num_de_la_chambre);
supprimer_etudiant(identifiant);
afficher_tout(treeview);

}


}

void
on_buttonactualiseraff_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview;
treeview=lookup_widget(button,"treeview1");
afficher_tout(treeview);
}


void
on_buttonquitteraff_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *tache,*windowaff;
windowaff=lookup_widget(button,"windowaff");
gtk_widget_destroy(windowaff);
tache=create_windowtache();
gtk_widget_show(tache);
}


void
on_button3chercherniv_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *foyer,*niveau, *togglebutton, *labelnivfoyeh; 
int i;
char message [50];
foyer=lookup_widget(togglebutton,"comboboxfoyeh");
strcpy(eh.foyer,gtk_combo_box_get_active_text(GTK_COMBO_BOX(foyer)));
niveau = lookup_widget(togglebutton,"entryniveau");
strcpy(eh.niveau, gtk_entry_get_text(GTK_ENTRY(niveau)));
if(strcmp(niveau,"")==0){
gtk_label_set_text(GTK_LABEL(labelnivfoyeh)," veuillez remplir les champs ! ");
}
else
{

i=etudiant_par_etage(niveau,foyer);
sprintf(message,"le nombre d'etudiant du foyer %s du niveau %s est %d",foyer,niveau,i);
gtk_label_set_text(GTK_LABEL(labelnivfoyeh),message);
}
}

