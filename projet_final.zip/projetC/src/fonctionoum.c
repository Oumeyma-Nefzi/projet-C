#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include"fonctionoum.h"




int ajouter_etudiant(etudiant_heberge eh1)
{
etudiant_heberge eh;
FILE *f;
int found=0;

f=fopen("hebergement.txt","a") ;

if(f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF) 
{
if (strcmp(eh.identifiant ,eh1.identifiant)==0) 
{
found=1;
break;
}
}
}
if (found==0)
{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh1.nom,eh1.prenom,eh1.identifiant,eh1.classe,eh1.sexe,eh1.num_telephone,eh1.nom_parent,eh1.prenom_parent,eh1.num_telephone_parent,eh1.foyer,eh1.niveau,eh1.num_de_la_chambre) ;
fclose(f);
return 1;
}

return 0;
}



void modifier_etudiant (etudiant_heberge eh1)
{
etudiant_heberge eh;
FILE *f;
FILE *f1;
f1=NULL ;
f=fopen("hebergement.txt","r+");
f1=fopen("hebergement1.txt","a+");
if (f!= NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF) 
{
if (strcmp(eh1.identifiant ,eh.identifiant)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh1.nom,eh1.prenom,eh1.identifiant,eh1.classe,eh1.sexe,eh1.num_telephone,eh1.nom_parent,eh1.prenom_parent,eh1.num_telephone_parent,eh1.foyer,eh1.niveau,eh1.num_de_la_chambre) ;
}
else
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre) ;
}
fclose(f1);
fclose(f);
remove("hebergement.txt");
rename ("hebergement1.txt","hebergement.txt");
}
}



void supprimer_etudiant (char identifiant[])
{
etudiant_heberge eh;
FILE *f;
FILE *f1 ;
f1 =NULL;
f=fopen("hebergement.txt","r") ;
f1=fopen("hebergement1.txt","a");
if (f!= NULL)
{

while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF)
{
if (strcmp(identifiant,eh.identifiant)!=0)
{


fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre) ;
}
}
}


fclose(f);
fclose(f1);
remove("hebergement.txt");
rename("hebergement1.txt","hebergement.txt");
}



void rechercher_etudiant (char identifiant[])
{
etudiant_heberge eh;
FILE *f ;
f = fopen("hebergement.txt", "r");
if (f!=NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre)!=EOF)
{ 	
if (strcmp(identifiant,eh.identifiant)==0)
{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",eh.nom,eh.prenom,eh.identifiant,eh.classe,eh.sexe,eh.num_telephone,eh.nom_parent,eh.prenom_parent,eh.num_telephone_parent,eh.foyer,eh.niveau,eh.num_de_la_chambre) ;
}
}
fclose(f);
}
}



enum
{
	NOM,
	PRENOM,
	IDN,
	CLASSE,
	SEXE,
	NUM_T,
	NOM_P,
	PRENOM_P,
	NUM_T_P,
	FOYER, 
	NIVEAU,
	NUMC,
	COLUMNS,
};



void afficher_tout(GtkWidget *liste) 
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char nom[20];
	char prenom[20];
	char identifiant[20];
	char classe[10];
	char sexe [10];

	char num_telephone[20];
	char nom_parent[20];
	char prenom_parent[20];
	char num_telephone_parent[20];
	char foyer[10]; 
	char niveau[20];
	char num_de_la_chambre[10];
	
	store=NULL;
	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom",renderer, "text",NOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom",renderer, "text",PRENOM, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();	
		column = gtk_tree_view_column_new_with_attributes("identifiant",renderer, "text",IDN, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("classe",renderer, "text",CLASSE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("sexe",renderer, "text",SEXE, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		
		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("num telephone",renderer, "text",NUM_T, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("nom parent",renderer, "text",NOM_P, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("prenom parent",renderer, "text",PRENOM_P, NULL);
	renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		column = gtk_tree_view_column_new_with_attributes("num de telephone de parent",renderer, "text",NUM_T_P, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


		renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("foyer",renderer, "text",FOYER, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
renderer = gtk_cell_renderer_text_new();
		column = gtk_tree_view_column_new_with_attributes("niveau",renderer, "text",NIVEAU, NULL);
renderer = gtk_cell_renderer_text_new();
gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
		column = gtk_tree_view_column_new_with_attributes("num de la chambre",renderer, "text",NUMC, NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);


	}	
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);


f=fopen("hebergement.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("hebergement.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",nom,prenom,identifiant,classe,sexe,num_telephone,nom_parent,prenom_parent,num_telephone_parent,foyer,niveau,num_de_la_chambre)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set(store, &iter,NOM,nom,PRENOM,prenom,IDN,identifiant,CLASSE,classe,SEXE,sexe,NUM_T,num_telephone,NOM_P,nom_parent,PRENOM_P,prenom_parent,NUM_T_P,num_telephone_parent,FOYER,foyer,NIVEAU,niveau,NUMC,num_de_la_chambre, -1);
}
}

fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref (store);

}

int etudiant_par_etage(char niveau[] ,char foyer[])
{
FILE *f ;
f=fopen("hebergement.txt","a+");
int i;
if (f!=NULL)
{
while (fscanf(f,"%s %s  \n",eh.foyer,eh.niveau)!=EOF)
{
if(strcmp(foyer,eh.foyer)==0 && strcmp(niveau,eh.niveau)==0)
{

i++;

}
}
}
fclose(f);
return(i);

}





int verif( char identifiant[])
{
etudiant_heberge eh;
int t=0;
FILE *f=NULL;
char id[20];


f=fopen("hebergement.txt","r");
if(f!=NULL)
{
while (fscanf(f,"%s",id)!=EOF)
{
if(strcmp(id,eh.identifiant)==0)
t=1;
}

fclose(f);
}

return t;
}

