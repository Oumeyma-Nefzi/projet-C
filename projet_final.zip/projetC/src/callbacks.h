#include <gtk/gtk.h>
#include "fonctionoum.h"

void
on_inscription_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_login_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonlog_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitter1_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttoninscri_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsup_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaff_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonnb_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonsup1_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonenregistrer_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonf_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonm_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonajout_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewaff_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonact_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittajout_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittmodif_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittrech_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittsupp_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquittnbet_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonquittaff_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiser_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffniv_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactualiseraff_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonquitteraff_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3chercherniv_clicked          (GtkButton       *button,
                                        gpointer         user_data);
